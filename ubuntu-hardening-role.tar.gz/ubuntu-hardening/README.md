# Ubuntu Hardening Ansible Role

## Install required collection

```bash
ansible-galaxy collection install -r requirements.yml
```

## Syntax check

```bash
ansible-playbook -i inventory.ini site.yml --syntax-check
```

## Run

```bash
ansible-playbook -i inventory.ini site.yml
```

> Test in a non-production environment before deploying SSH, firewall, or kernel hardening changes.
